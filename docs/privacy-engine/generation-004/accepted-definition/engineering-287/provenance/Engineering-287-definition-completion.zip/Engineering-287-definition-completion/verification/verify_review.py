"""Engineering[287] focused defect/repair checks. Synthetic in-memory values only.
No profile, signatures, appointments, source facts or privacy PASS are produced.
"""
from pathlib import Path
import csv
import copy
import hashlib
import json
import runpy
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
TEMP = tempfile.TemporaryDirectory(prefix='e287-review-')
with zipfile.ZipFile(ROOT / 'supplied-input.zip') as supplied:
    target = Path(TEMP.name).resolve()
    for member in supplied.namelist():
        if not (target / member).resolve().is_relative_to(target):
            raise ValueError('unsafe archive path')
    supplied.extractall(target)
OLD = Path(TEMP.name) / 'PE-G4-definition-review'
NEW = ROOT / 'corrected-author-basis'
G = runpy.run_path(str(NEW / 'definition-completion/v4_record_grammar.py'))
B = runpy.run_path(str(OLD / 'definition-completion/budget.py'))
checks = []

def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)

def reject(name, function, value):
    try:
        function(value)
    except (ValueError, TypeError, KeyError):
        checks.append(name)
    else:
        raise AssertionError(name)

ref = dict(owner_source_id='SYNTHETIC', source_anchor='TEST', source_sha256='0' * 64, material_sha256='0' * 64)

def value(kind):
    if kind == 'ID': return 'SYNTHETIC'
    if kind == 'DIGEST': return '0' * 64
    if kind == 'BYTES': return ''
    if kind == 'UINT': return 0
    if kind == 'RATIONAL': return [0, 1]
    if kind == 'SOURCE-REF': return dict(ref)
    if kind.startswith('LIST-'): return []
    return sorted(G['ENUM'][kind[5:]])[0]

def record(schema):
    v = {k: value(t) for k, t in G['SPEC'][schema].items()}
    if schema == 'OBLIGATION':
        v.update(kind='EXACT', experiment_id=None)
    if schema == 'COMPOSITION':
        v.update(method='UNION', theorem_ref=None)
    if schema == 'ASSESSMENT':
        v.update(complete_result='UNAVAILABLE', validated_bound=None)
    return v

# Original bound-1 counterexample is numerical truth, not a successful admission.
v = B['union_budget']([dict(argument_id='TEST', bound=[1, 1], multiplicity=1)], [1, 1])
check('original maximum-one accepts a tautological bound arithmetically', v['budget_result'] == 'WITHIN')
check('arithmetic grants no profile admission', v['profile_admitted'] is False)

for schema in G['SCHEMAS']:
    check('registered record shape ' + schema, G['record_shape'](schema, record(schema)) is not None)
unavailable = record('ASSESSMENT')
check('completed unavailable has null bound', unavailable['validated_bound'] is None)
reject('unavailable cannot carry fake zero bound', lambda x: G['record_shape']('ASSESSMENT', x), {**unavailable, 'validated_bound': [0, 1]})
reject('VALID cannot carry absent bound', lambda x: G['record_shape']('ASSESSMENT', x), {**unavailable, 'complete_result': 'VALID'})
reject('INVALID cannot carry bound', lambda x: G['record_shape']('ASSESSMENT', x), {**unavailable, 'complete_result': 'INVALID', 'validated_bound': [0, 1]})

o = record('OBLIGATION')
ot = {k: o[k] for k in G['OBLIGATION_TEMPLATE']}
check('static obligation has no result or self digest', not {'profile_digest', 'model_digest', 'disposition', 'argument_ids', 'exact_evidence_refs'} & set(ot))
check('static obligation template accepted as shape', G['record_shape']('OBLIGATION', ot, True) is not None)
reject('static self digest rejected', lambda x: G['record_shape']('OBLIGATION', x, True), {**ot, 'profile_digest': '0' * 64})
reject('static result rejected', lambda x: G['record_shape']('OBLIGATION', x, True), {**ot, 'disposition': 'EXACT-SATISFIED'})
reject('computational obligation needs experiment', lambda x: G['record_shape']('OBLIGATION', x, True), {**ot, 'kind': 'COMPUTATIONAL'})
c = record('COMPOSITION')
ct = {k: c[k] for k in G['COMPOSITION_TEMPLATE']}
check('static composition separates actual terms', G['record_shape']('COMPOSITION', ct, True) is not None)
reject('static computed bound rejected', lambda x: G['record_shape']('COMPOSITION', x, True), {**ct, 'composed_bound': [0, 1]})
reject('qualified theorem needs reference', lambda x: G['record_shape']('COMPOSITION', x, True), {**ct, 'method': 'SOURCE-QUALIFIED-THEOREM'})

e = {'format': 'PE-G4-SECURITY-RECORDS-V4', 'profile_digest': '0' * 64, 'phase': 'STATIC-ADMISSION',
     'records': {s: {'status': 'UNAVAILABLE', 'justification': None, 'instances': []} for s in G['SCHEMAS']}}
check('unavailable object is representable but not admission evidence', G['evidence_shape'](e) is not None)
bad = copy.deepcopy(e); bad['records']['ASSESSMENT']['status'] = 'PRESENT'
reject('PRESENT requires record', G['evidence_shape'], bad)
bad = copy.deepcopy(e); bad['records']['ASSESSMENT']['status'] = 'INAPPLICABLE'
reject('inapplicability needs source justification', G['evidence_shape'], bad)
bad = copy.deepcopy(e); bad['records'].pop('POLICY')
reject('omitted schema directory rejected', G['evidence_shape'], bad)
bad = copy.deepcopy(e); bad['records']['ASSESSMENT'].update(status='PRESENT', instances=[unavailable])
check('completed unavailable assessment distinct from absent invocation', G['evidence_shape'](bad) is not None)
bad['records']['ASSESSMENT']['instances'].append(unavailable)
reject('duplicate record identity rejected', G['evidence_shape'], bad)

for name, raw in [('duplicate JSON key', b'{"a":1,"a":2}\n'), ('floating point', b'{"a":0.5}\n'),
                  ('noncanonical whitespace', b'{ "a":1}\n'), ('missing LF', b'{"a":1}'), ('nonfinite', b'{"a":NaN}\n')]:
    reject(name, G['parse'], raw)
check('canonical round trip', G['parse'](G['canonical'](e)) == e)
check('absence digest differs from present empty bytes', G['field_digest'](None) != G['field_digest'](''))
check('canonical type retained in digest', G['field_digest'](False) != G['field_digest'](0))

for p in (OLD / 'sources').rglob('*.md'):
    if p.name != 'PE-G4-SOURCE-S90.md':
        check('preserved source ' + str(p.relative_to(OLD)), p.read_bytes() == (NEW / p.relative_to(OLD)).read_bytes())
for n in ['profile/fragments/fields.tsv',
          'profile/fragments/entry.json', 'profile/fragments/BOUNDED-NOT-ADMITTED-projection.tsv',
          'definition-completion/security-fields.tsv', 'definition-completion/security-custody.tsv']:
    check('preserved ' + n, (OLD / n).read_bytes() == (NEW / n).read_bytes())
old_requirements = json.loads((OLD / 'composition/requirement-inventory.json').read_text())
new_requirements = json.loads((NEW / 'composition/requirement-inventory.json').read_text())
check('all 971 prior requirement records preserved exactly', new_requirements[:971] == old_requirements)
check('approved non-vacuity has one new normative home', len(new_requirements) == 972 and new_requirements[-1]['requirement_id'] == 'PE-G4-CAP-111')
NB = runpy.run_path(str(NEW / 'definition-completion/budget.py'))
reject('approved A denies original tautological ceiling', lambda x: NB['union_budget']([dict(argument_id='TEST', bound=[1, 1], multiplicity=1)], x), [1, 1])
for kind in G['ENUM']['EXPERIMENT']:
    experiment = record('EXPERIMENT'); experiment['kind'] = kind
    check('valid experiment maximum in ' + kind, G['record_shape']('EXPERIMENT', experiment) is not None)
    reject('maximum-one rejected in ' + kind, lambda x: G['record_shape']('EXPERIMENT', x), {**experiment, 'maximum': [1, 1]})
    reject('noncanonical one rejected in ' + kind, lambda x: G['record_shape']('EXPERIMENT', x), {**experiment, 'maximum': [2, 2]})
check('zero ceiling with established zero term is representable', NB['union_budget']([dict(argument_id='TEST', bound=[0, 1], multiplicity=1)], [0, 1])['budget_result'] == 'WITHIN')
check('qualified bound one remains representable but exceeds allowed maximum', NB['union_budget']([dict(argument_id='TEST', bound=[1, 1], multiplicity=1)], [999, 1000])['budget_result'] == 'EXCEEDED')
check('arbitrarily weak sub-one target is explicit, not a practical-security claim', NB['policy_maximum']([999, 1000]).numerator == 999)
for bad in ([2, 2], [2, 1], [1, 0], [-1, 2], [True, 2], [0.5, 1]):
    reject('malformed maximum ' + repr(bad), NB['policy_maximum'], bad)

with (NEW / 'definition-completion/security-framing-fields.tsv').open() as f:
    framing = list(csv.DictReader(f, delimiter='\t'))
check('all status/count/directory/presence field classes registered', len(framing) == 224 and len({x['surface_id'] for x in framing}) == 224)
with (NEW / 'definition-completion/framing-custody.tsv').open() as f:
    custody = list(csv.DictReader(f, delimiter='\t'))
check('new custody never silently qualified', len(custody) == 224 * 7 and all(x['visibility'] == 'UNKNOWN' for x in custody))
source = (NEW / 'sources/PE-G4-SOURCE-S90.md').read_text()
for name in ['E287-SOURCE-DETERMINED-CORRECTION.txt', 'v4_record_grammar.py', 'security-framing-fields.tsv', 'framing-custody.tsv', 'assemble_definition.py', 'ACCEPTANCE-CONTRACT.txt', 'NONVACUITY-CONTRACT.txt']:
    check('exact owning source embeds ' + name, (NEW / 'definition-completion' / name).read_text() in source)

report = {'result': 'PASS-FOCUSED-DEFECT-AND-AUTHOR-REPAIR-CHECKS', 'checks': checks,
          'definition_verdict_on_supplied_package': 'BLOCKED', 'budget_floor_decision': 'A-APPROVED-AND-INTEGRATED',
          'corrections_independently_accepted': False, 'source_appointed': False, 'privacy_admitted': False,
          'governing_V4_profile_constructed': False, 'publication_performed': False}
(ROOT / 'verification/focused-checks.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS:', len(checks), 'focused representation/preservation checks; original maximum-one counterexample confirmed.')
print('PASS: A is integrated in grammar, budget procedure and normative source; no actual privacy/admission asserted.')
